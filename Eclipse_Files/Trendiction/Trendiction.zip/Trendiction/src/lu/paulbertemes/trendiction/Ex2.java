//Package
package lu.paulbertemes.trendiction;

/**
 * @author paulbertemes
 */
//Exercice 2: Find Punctuation in Text
public class Ex2 
{
	private String 		sExampleText = "Trendiction. The company trendiction maps...";
	private int[]  		nOcc 		 = {0,0,0};
	private String[] 	WordList;
	
	public Ex2()
	{	
		String[] 	sExampleChar 	= {"\n"," "};
		String[] 	sLabels   		= {"\\n: ",", \\s: ",",  words: "};
		
		for(int i=0;i<2;i++)
		{
			WordList = sExampleText.split(sExampleChar[i]);
			nOcc[i]  = WordList.length-1;
		}
		
		nOcc[2] = WordList.length;
		
		for(int j=0;j<3;j++)
			System.out.print(sLabels[j] + nOcc[j]);
		
		System.out.print("\n");
	}
}
