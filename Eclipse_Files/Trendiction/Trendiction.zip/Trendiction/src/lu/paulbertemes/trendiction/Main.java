/**
 * 
 */
package lu.paulbertemes.trendiction;

/**
 * @author paulbertemes
 *
 */
public class Main {

	/**
	 * @param args
	 */
	public static void main(String[] args) 
	{
//		Ex1 ex1 = new Ex1();
//		Ex2 ex2 = new Ex2();
//		Ex3 ex3a = new Ex3("12abcbaxyaba");
//		Ex3 ex3b = new Ex3("abcdefg");
		Ex5 ex5  = new Ex5();
	}

}
