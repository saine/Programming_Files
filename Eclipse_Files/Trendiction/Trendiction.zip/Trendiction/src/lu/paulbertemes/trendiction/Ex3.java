package lu.paulbertemes.trendiction;

import java.util.ArrayList;
import java.util.TreeMap;

public class Ex3
{
	private TreeMap<Integer,String> aPalindromeList  = new TreeMap<Integer,String>();
	private String 					sTextLine;
	
	public Ex3(String sText)
	{
		ArrayList<String> sPalList = new ArrayList<String>();
	    sTextLine				   = sText;
		
		//Find Possible Palindromes 
	    for(int i=0;i<sText.length();i++)
	    {
	    	for(int j=i+1;j<sText.length();j++) 
	    		if(sText.charAt(i) == sText.charAt(j)) sPalList.add(sText.substring(i,j+1));
	    }
	    
	    //Find Longest Palindrome
	    checkPalindromes(sPalList);
	}
	
	private void checkPalindromes(ArrayList<String> sPalindromes) 
	{	
		for(int i=0;i<sPalindromes.size();i++)
		{
			boolean nSucceeded 	= true;
			String 	sTestSeq 	= sPalindromes.get(i).toUpperCase();
				
			while(sTestSeq.length() > 1)
			{
				char firstChar = sTestSeq.charAt(0);
				char lastChar  = sTestSeq .charAt(sTestSeq.length()-1);
					
				if(firstChar == lastChar)
					sTestSeq = sTestSeq.substring(1, sTestSeq.length()-1);
				else
				{
					nSucceeded = false;
					break;
				}
			}			
			if(nSucceeded) aPalindromeList.put(sPalindromes.get(i).length(),sPalindromes.get(i));
		}
		
		//Check if Palindrome list is zero
		if(aPalindromeList.size() == 0) aPalindromeList.put(1, sTextLine.substring(0, 1));
		
		//Print Results
		System.out.println("The longest palindrome is "+aPalindromeList.lastEntry());
	}
}
