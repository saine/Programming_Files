package lu.paulbertemes.trendiction;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Random;

public class Ex5
{
	int						nc					= 0;
	ArrayList<Container> 	ContainerList 		= new ArrayList<Container>();
	
	//Container Class
	private class Container
	{	
		private 				int 	np;
		private static final 	int 	maxSize = 5000;
		private 				int 	occupied;
		private 				boolean shipped;
		
		public Container()
		{
			occupied = 0;
			shipped  = false;
			np 		 = 0;
		}
		
		public int avail()
		{
			return(maxSize - occupied);
		}
		
		public void pack(int packageSize)
		{
			np++;
			occupied += packageSize; 
		}
	
		public void printUsedVolume(int j)
		{
			System.out.println("Container "+j+" volume used: "+occupied+" with "+np+" packages");
		}
	}
	
	public Ex5()
	{
		int    np		= 1000;
		Random rndGen 	= new Random();
		int[] packages 	= new int[np];
		
		for(int k=0;k<np;k++) packages[k] = rndGen.nextInt(999)+1;
		packages = reverseOrder(packages);
		
		//Pack Into Containers
		for(int i=0;i<np;i++) packIntoContainer(packages[i], packages);
		
		//Print Usage
		for(int j=0;j<(nc+1);j++) ContainerList.get(j).printUsedVolume(j+1);
	}
	
	private int[] reverseOrder(int[] packages)
	{
		int[] packs = new int[packages.length];
		int   j     = 0;
		
		Arrays.sort(packages);
		
		for(int i=packages.length;i>0;i--)
		{
			packs[j] = packages[i-1];
			j++;
			
		}
		return(packs);
	}
	
	private void packIntoContainer(int packageSize, int[] packages)
	{
		boolean placed = false;
		
		//Initialize Container List
		if(ContainerList.size() == 0) ContainerList.add(new Container());
		
		for(int i=0;i<ContainerList.size();i++)
		{
			//Check to ship container
			if(ContainerList.get(i).avail() < packages[packages.length-1])
				ContainerList.get(i).shipped = true;
			
			if((packageSize <= ContainerList.get(i).avail()) && ContainerList.get(i).shipped == false)
			{
				ContainerList.get(i).pack(packageSize);
				placed = true;
				break;
			}
		}
		if(placed == false)
		{
			Container newCont = new Container();
			newCont.pack(packageSize);
			
			ContainerList.add(newCont);
			nc++;
		}
	}
}
