//Package
package lu.paulbertemes.trendiction;

//Imports
import java.util.StringTokenizer;
import java.util.TreeMap;

/**
 * @author paulbertemes
 */
//Exercice 1: Find Word Occurrences
public class Ex1 
{
	private String 					sExampleText = "Trendiction. The company trendiction maps";
	private TreeMap<String,Integer> aTree 		 = new TreeMap<String,Integer>();
	
	public Ex1()
	{
		sExampleText = sExampleText.toLowerCase();
		StringTokenizer parser = new StringTokenizer(sExampleText);
		
		while (parser.hasMoreTokens()) 
		{
			String 	sWord = stripPunctuation(parser.nextToken());
		    Integer nOcc  = aTree.get(sWord); 
		    
		    if (nOcc==null) nOcc = 0;
			aTree.put(sWord, nOcc+1); 
		}
		System.out.println(aTree);
	}
	
	//Strip punctuation from Words
	private String stripPunctuation(String sWord)
	{
		if(sWord.endsWith(",") || sWord.endsWith("."))
			return(sWord.substring(0, sWord.length()-1));
		else
			return(sWord);
	}
}
